﻿using myApi.Models;
using System.Collections.Generic;

namespace myApi.Repository
{
    public interface IPersonRepository
    {
        void AddNew(Person p);
        Person GetDetail(string aadhar);
        List<Person> GetPeople();
        void Remove(string aadhar);
        void Update(string aadhar, Person p);
    }
}