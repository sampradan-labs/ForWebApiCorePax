﻿using myApi.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace myApi.Repository
{

    public class PersonRepository : IPersonRepository
    {
        public string checkValue = "Person Repo";
        private static List<Person> _people = new List<Person>();
        public List<Person> GetPeople()
        {
            checkValue = "GetPeople";
            if (_people.Count == 0)
            {
                _people.Add(new Person()
                {
                    Aadhar = "AA1234ZZ",
                    Name = "Archana",
                    Age = 30,
                    Email = "archana@danske.com",
                    Gender = "Female"
                });
                _people.Add(new Person() { Aadhar = "BB1234ZZ", Name = "Sulochana", Age = 20, Email = "sulochana@danske.com", Gender = "Female" });
                _people.Add(new Person() { Aadhar = "CC1234ZZ", Name = "Chanakeshav", Age = 35, Email = "Chanakeshav@danske.com", Gender = "Male" });
            }
            return _people;
        }

        public Person GetDetail(string aadhar)
        {
            checkValue = "GetDetail";
            return _people.Where(p => p.Aadhar == aadhar)
                .FirstOrDefault();
            //foreach (var p in _people)
            //{
            //    if (p.Aadhar==aadhar)
            //    {
            //        return p;
            //    }
            //}
        }

        public void AddNew(Person p)
        {
            _people.Add(p);
        }

        public void Update(string aadhar, Person p)
        {
            //find the person
            Person tobeupdated = GetDetail(aadhar);
            tobeupdated.Name = p.Name;
        }

        public void Remove(string aadhar)
        {
            var tobedeleted = _people.Where(p => p.Aadhar == aadhar).FirstOrDefault();
            _people.Remove(tobedeleted);
        }


    }
}
