﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using myApi.Models;
using myApi.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;


namespace myApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class FirstController : ControllerBase
    {
        IPersonRepository personDB;
        public FirstController(IPersonRepository repo)  //Object of personRepository provided by IOC container
        {
            personDB = repo;
        }

        [HttpGet("/names")] //localhost:5001/names
        public string[] GetNames()
        {
            return new string[] { "Eena", "Meena", "Deeka" };
        }

        [HttpGet("usingAction")]
        [ProducesDefaultResponseType()]
        [ProducesResponseType(200)]
        public List<string> GetPlacesUsingAttributes()
        {
            return new List<string>() { "Pune", "Mumbai", "Delhi", "Bangalore" };
        }

        [HttpGet("/getsingle/{placeId}")]    //=> RouteParam  getsingle/1001, getsingle?speciality=""
        public string GetSinglePlace([FromRoute] string placeId, [FromQuery] string speciality)
        {
            return $"{placeId} is known for {speciality}";
        }

        [HttpGet("/async")]
        public async Task<string> GetName()
        {
            string result = await Task.Run(() => { Thread.Sleep(5000);
                                                    return "Abhijit";
                                                }) ;
            return result;
        }

        [HttpGet("/people")]    //localhost:5001/people
        public IEnumerable<Person> GetAll()
        {
            var result = personDB.GetPeople();
            //var check = ((PersonRepository)personDB).checkValue;
            return result;
        }

        
        [HttpGet("/people/best")]   //localhost:5001/people/best
        public IActionResult GetAllBestPractice()
        {
            return Ok(personDB.GetPeople());
        }

        [HttpGet("/person")] //localhost:5001/person?aadhar=AA
        public Person GetDetail([FromQuery] string aadhar)
        {
           var result = personDB.GetDetail(aadhar);
            var check = ((PersonRepository)personDB).checkValue;
            return result;
        }

        [HttpGet("/best/{aadhar}")] //localhost:5001/person/AA
        public IActionResult GetDetailBest([FromRoute] string aadhar)
        {
            var result = personDB.GetDetail(aadhar);
            if (result == null)
            {
                return NotFound($"Not found person with aadhar: {aadhar}");
            }
           
                return Ok(result);
            
        }

        [HttpPost("/person/add")]
        public IActionResult AddPerson([FromBody] Person p)
        {
            //if (ModelState.IsValid)
            //{
                personDB.AddNew(p);
                return Created("/person/add", $"Creation successful. Aadhar Id: {p.Aadhar}");
                //We have a created a new Http Response at:
                //                                 https://         localhost:port             /person/add             The object p
                return Created(HttpContext.Request.Scheme + "://"
                                + HttpContext.Request.Host
                                + HttpContext.Request.Path + "/",
                              p);

            //}
            //else
            //{
            //    return StatusCode(500); //internal server error
            //}

        }

        [HttpPost("/Login")]
        public IActionResult Login([FromForm] string username, [FromForm] string pwd, [FromHeader] string token)
        {
            if (username == "admin" && pwd == "$#abc!!" && token == "token")
            {
                return Created("/dashboard.aspx", "success");
            }

            return BadRequest("Invalid input username or password");
        }

        [HttpGet("/isvalid/{s:alpha:maxlength(5)}/{i:int:range(18,99)}/{istrue:bool?}")]
       public IActionResult TypeConstraints(string s, int i, bool? istrue)
        {
            return Ok("All passed");
        }

    }
}
