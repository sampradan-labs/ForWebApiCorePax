﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace myApi.Models
{
    public class Person
    {
        [Key]
        public string Aadhar { get; set; }

        [Required(ErrorMessage ="Name is mandatory")]
        [StringLength(20, ErrorMessage ="The length of Name cannot be greater than 20 characters long")]
        public string Name { get; set; }

        [Range(18,99)]  
        public int Age { get; set; }

        [Required]
        public string Gender { get; set; }

        [EmailAddress]
        public string Email { get; set; }

        [RegularExpression("^/d{6}$")]
        public string Pincode { get; set; }
    }
}