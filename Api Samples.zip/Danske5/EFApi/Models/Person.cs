﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace EFApi.Models
{
    
    public class Person
    {
        public enum Gender
        {
            Male, Female
        }
        [Key]
        public Int32 AadharNumber { get; set; }
        public string Name { get; set; }

        [Range(18,99)]
        public Int32 Age { get; set; }
        public Gender PersonGender { get; set; }
    }
}
