﻿using EFApi.Data;
using EFApi.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EFApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class MyProductController : ControllerBase
    {
        private EFApiContext _repo;
        public MyProductController(EFApiContext repository)
        {
            _repo = repository;
        }

        [HttpGet("/all")]
        public IActionResult Get()
        {
            return Ok(_repo.Person.ToList());
        }

        [HttpPost("/add")]
        public IActionResult Add([FromBody] Person p)
        {
            _repo.Add(p);
            _repo.SaveChanges();
            return Created("/add",p);
        }
    }
}
