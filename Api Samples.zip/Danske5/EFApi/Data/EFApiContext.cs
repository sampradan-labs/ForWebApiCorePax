﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using EFApi.Models;

namespace EFApi.Data
{
    public class EFApiContext : DbContext
    {
        public EFApiContext (DbContextOptions<EFApiContext> options)
            : base(options)
        {
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            //modelBuilder.Entity<Person>()
            //    .Property("PersonGender")
            //    .HasConversion<int>();
            base.OnModelCreating(modelBuilder);
        }

        public DbSet<EFApi.Models.Person> Person { get; set; }
        public DbSet<EFApi.Models.Employee> Employees { get; set; }
        public DbSet<EFApi.Models.Department> Departments { get; set; }

    }
}
