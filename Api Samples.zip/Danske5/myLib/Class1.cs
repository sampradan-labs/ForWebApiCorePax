﻿using System;

namespace myLib
{
    public class Class1
    {
    }
}
