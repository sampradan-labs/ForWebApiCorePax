﻿using System;
using System.Collections.Generic;

namespace FirstTest
{
    public class MathTestData
    {
        public static IEnumerable<object[]> SubTestData()
        {
            return new List<object[]>(){
                new object[]{10,20,-10},
                new object[]{-10,-20,10},
                new object[]{999.5, 999.5, 0}
            };
        }

        public static IEnumerable<object[]> InvalidSubInputs()
        {
            return new List<object[]> { 
                new object[]{null,20,new Exception("Invalid Input!") },
                new object[]{ 20,null,new Exception("Invalid Input!") }
            };
        }
    }
}