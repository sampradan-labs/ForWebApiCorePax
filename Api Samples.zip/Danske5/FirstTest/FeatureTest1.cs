using MathOperations;
using Moq;
using myApi.Controllers;
using myApi.Models;
using myApi.Repository;
using Newtonsoft.Json.Linq;
using RestSharp;
using System;
using System.Collections.Generic;
using Xunit;

namespace FirstTest
{
    public class FeatureTest1
    {
        public FeatureTest1()
        {
            //setup logic
        }

        [Fact]
        public void Test1()
        {
            bool istrue = true;
            Assert.True(istrue);
        }

        [Fact]
        [Trait("Sprint 2","This is not implemented")]
        public void NormalFunction() {
            Assert.True(true);
              }


        [Theory]
        [InlineData(10,20,30)]
        [InlineData(-10, 20, 10)]
        [InlineData(999.5, 999.5, 1999.0)]
        public void Test_Add_two_numbers(double n1, double n2, double expected)
        {
            //GIVEN - Arrange of inputs
            //WHEN - Action to be performed
            var result =MathOps.Add(n1, n2);
            //THEN - Assert to pass / fail
            Assert.Equal(expected, result);
        }

        [Theory]
        [MemberData(nameof(MathTestData.SubTestData), MemberType = typeof(MathTestData))]
        public void Test_Subtract_two_numbers(double n1, double n2, double expected)
        {
            //GIVEN - Arrange of inputs
            //WHEN - Action to be performed
            var result = MathOps.Subtract(n1, n2);
            //THEN - Assert to pass / fail
            Assert.Equal(expected, result);
            Assert.NotNull(result); //result != null
           
        }

        [Fact]
        public void Test_Collection()
        {
            List<string> strings = new List<string>() { "Eena", "Meena", "Deeka", "Teena" };
            Assert.All<string>(strings, (string item) => Assert.Contains("e",item));
            Assert.Collection<string>(strings,
                                            (s1) => Assert.StartsWith("Ee",s1),
                                            (s2) => Assert.StartsWith("Me", s2),
                                            (s3) => Assert.EndsWith("ka", s3),
                                            (s4) => Assert.EndsWith("na", s4)
                                      );
        }

        [Theory]
        [MemberData(nameof(MathTestData.InvalidSubInputs), MemberType = typeof(MathTestData))]
        public void Test_Add_two_invalid_numbers(double? n1, double? n2, Exception expected)
        {
            Assert.Throws<Exception>(() => MathOps.Add(n1, n2));

            string actualErr = Assert.Throws<Exception>(() => MathOps.Add(n1, n2)).Message;
            Assert.Equal(expected.Message, actualErr);
        }

        [Fact]
        public void Test_Instantiate_FirstApi_Controller_NormalWay()
        {
            //GIVEN: FirstController class, PersonRepository class that implements IPersonRepository
            PersonRepository repo = new PersonRepository();
            

            //WHEN: Instantiation is done
             FirstController controller = new FirstController(repo);

            //THEN: Instance creation should be successful
            //      Instance should not be null
            //
            Assert.True(controller != null);
            Assert.NotNull(controller);
            Assert.IsType<FirstController>(controller);
        }

        [Fact]
        public void Test_DI_while_instantiating_First_Controller()
        {
            Mock<IPersonRepository> mockRepo = new Mock<IPersonRepository>();
            //WHEN: Instantiate FirstController
            var controller = new FirstController(mockRepo.Object);
            //Assert
            Assert.NotNull(controller);
            Assert.IsType<FirstController>(controller);
            mockRepo.Verify();
        }
        [Fact]
        public void Test_Call_GetAll_Using_Moq()
        {
            Mock<IPersonRepository> mockRepo = new Mock<IPersonRepository>();
            //WHEN: Instantiate FirstController
            var controller = new FirstController(mockRepo.Object);
            mockRepo.Setup((repo) => repo.GetPeople())
                    .Returns(new List<Person>() { });

            //Call GetAll()
            IEnumerable<Person> p = controller.GetAll();
            Assert.NotNull(p);

            //Verifying the workflow- Controller method must call 
            //IPersonRepository's GetPeople() method
            mockRepo.Verify((repo) => repo.GetPeople(), Times.Once);
        }

        [Fact]
        public void Test_Api()
        {
            RestClient client = new RestClient("https://localhost:5001/person/add");
            RestRequest req = new RestRequest();
            req.Method = Method.POST;
            JObject bodyParams = new JObject();
           
            bodyParams.Add("Aadhar", "12345");
            bodyParams.Add("Name", "Freddy");
            bodyParams.Add("Age", 30);
            bodyParams.Add("Gender", "Male");
            bodyParams.Add("Email", "Freddu@xyz.com");

            req.AddHeader("content-type", "application/json");
            req.AddParameter("p", bodyParams, ParameterType.RequestBody);

            //Get the response
            
            var res = client.Execute(req);

            //Assert the status code
            Assert.NotNull(res);
            Assert.Equal(201, Convert.ToInt32(res.StatusCode));
            Assert.NotNull(res.Content);

        }

    }

   
}
