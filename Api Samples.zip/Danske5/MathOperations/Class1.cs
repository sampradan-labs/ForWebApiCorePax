﻿using System;

namespace MathOperations
{
    public class MathOps
    {
        public static double Add(double? n1, double? n2)
        {
            if (n1==null || n2==null)
            {
                throw new Exception("Invalid Input!");
            }

            return Convert.ToDouble(n1) + Convert.ToDouble(n2);
        }

        public static double Subtract(double n1, double n2)
        {
            return n1 - n2;
        }
    }
}
